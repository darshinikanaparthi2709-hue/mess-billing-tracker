// ─── STATE ───
let config = {
  messName: 'Sri Karthikeya Deluxe Mess',
  location: 'Somajiguda, Hyderabad — 500082',
  defaultMeal: 'Egg Meals',
  prices: { egg: 80, veg: 70, chicken: 100 }
};

let companies = [
  { id: 1, name: 'Everest Infra Ventures India Pvt. Ltd.', since: 'Jan 2025' },
  { id: 2, name: 'MediJourn Solutions Pvt. Ltd.', since: 'Mar 2025' },
  { id: 3, name: 'Wadi Surgicals Pvt. Ltd.', since: 'Jun 2024' },
  { id: 4, name: 'Fristor Foods Pvt. Ltd.', since: 'Nov 2024' },
];

let entries = {}; // key: "YYYY-MM-DD_companyId" => {egg,veg,chicken}
let currentMonth = new Date();

// Today's date
const today = new Date();
const todayKey = today.toISOString().split('T')[0];

// MySQL Database Sync Configuration
let apiEndpoint = '';
let dbStatus = 'connecting';

// ─── UTILITIES ───
function calcAmount(egg, veg, chicken) {
  return egg * config.prices.egg + veg * config.prices.veg + chicken * config.prices.chicken;
}
function entryKey(compId, date) { return `${date || todayKey}_${compId}`; }
function getEntry(compId, date) { return entries[entryKey(compId, date)] || { egg: 0, veg: 0, chicken: 0 }; }
function setEntry(compId, egg, veg, chicken, date) {
  entries[entryKey(compId, date)] = { egg: +egg, veg: +veg, chicken: +chicken };
}

// ─── LOCAL STORAGE BACKUP ───
function loadLocalBackup() {
  try {
    const backup = localStorage.getItem('mess_entries');
    if (backup) {
      entries = JSON.parse(backup);
    }
  } catch (e) {
    console.error("Local storage load failed:", e);
  }
}

function saveLocalBackup() {
  try {
    localStorage.setItem('mess_entries', JSON.stringify(entries));
  } catch (e) {
    console.error("Local storage save failed:", e);
  }
}

// ─── DATABASE SYNC FUNCTIONS ───
async function detectBackend() {
  const badge = document.getElementById('db-sync-badge');
  const dot = document.getElementById('db-sync-dot');
  const text = document.getElementById('db-sync-text');

  function updateStatus(status, label) {
    dbStatus = status;
    if (text) text.textContent = label;
    if (badge && dot) {
      badge.className = 'sync-badge ' + status;
      dot.className = 'sync-dot ' + status;
    }
  }

  // 1. Try standard Python server API endpoint first
  try {
    const res = await fetch('/api/meals', { method: 'GET' });
    if (res.ok) {
      apiEndpoint = '/api/meals';
      updateStatus('connected', 'MySQL Live (Python)');
      await syncFromDatabase();
      return;
    }
  } catch(e) {}

  // 2. Try standard PHP file next
  try {
    const res = await fetch('api.php?action=get', { method: 'GET' });
    if (res.ok) {
      apiEndpoint = 'api.php';
      updateStatus('connected', 'MySQL Live (PHP)');
      await syncFromDatabase();
      return;
    }
  } catch(e) {}

  // 3. Fallback: Offline / Local backup mode
  updateStatus('offline', 'MySQL Offline (Local)');
  loadLocalBackup();
  renderDashboard();
}

async function syncFromDatabase() {
  if (!apiEndpoint) return;
  try {
    let url = apiEndpoint;
    if (apiEndpoint.includes('api.php')) {
      url += '?action=get';
    }
    const res = await fetch(url);
    const result = await res.json();
    if (result.status === 'success' && Array.isArray(result.data)) {
      result.data.forEach(row => {
        const key = `${row.entry_date}_1`; // 1 is Company ID for Everest Infra
        entries[key] = {
          egg: parseInt(row.EGG) || 0,
          veg: parseInt(row.VEG) || 0,
          chicken: parseInt(row.CHICKEN) || 0
        };
      });
      // Save local copy backup
      saveLocalBackup();
      
      // Force update all tables and counts on screen
      renderDashboard();
    }
  } catch (e) {
    console.error("Error syncing from database:", e);
    toast('Database sync failed, operating in offline backup mode.', '⚠');
  }
}

async function saveToDatabase(egg, veg, chicken, date) {
  if (!apiEndpoint) return;
  try {
    let url = apiEndpoint;
    if (apiEndpoint.includes('api.php')) {
      url += '?action=save';
    }
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ egg, veg, chicken, date })
    });
    const result = await res.json();
    if (result.status === 'success') {
      toast('Synced with MySQL successfully!', '🗄️');
    } else {
      toast('MySQL save failed: ' + result.message, '⚠');
    }
  } catch (e) {
    console.error("Error saving to database:", e);
    toast('Could not sync with MySQL database. Saved locally.', '💾');
  }
}

// ─── TOAST ───
function toast(msg, icon='✓') {
  const el = document.createElement('div');
  el.className = 'toast';
  el.innerHTML = `<span>${icon}</span> ${msg}`;
  document.getElementById('toast-wrap').appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

// ─── PAGE ROUTING ───
function showPage(id, navEl) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById(`page-${id}`).classList.add('active');
  if (navEl) navEl.classList.add('active');
  if (id === 'dashboard') renderDashboard();
  if (id === 'daily') renderDailyEntry();
  if (id === 'monthly') renderMonthly();
  if (id === 'companies') renderCompanies();
  if (id === 'setup') renderSetup();
}

// ─── DASHBOARD ───
function renderDashboard() {
  const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  document.getElementById('today-date-display').textContent =
    `${days[today.getDay()]}, ${today.getDate()} ${months[today.getMonth()]} ${today.getFullYear()}`;
  document.getElementById('date-badge-display').textContent =
    `${String(today.getDate()).padStart(2,'0')}-${String(today.getMonth()+1).padStart(2,'0')}-${today.getFullYear()}`;
  document.getElementById('default-meal-display').textContent = config.defaultMeal;

  let totalEgg=0, totalVeg=0, totalChicken=0;
  companies.forEach(c => {
    const e = getEntry(c.id);
    totalEgg += e.egg; totalVeg += e.veg; totalChicken += e.chicken;
  });

  animateNum('dash-egg', totalEgg);
  animateNum('dash-veg', totalVeg);
  animateNum('dash-chicken', totalChicken);
  animateNum('dash-total-plates', totalEgg + totalVeg + totalChicken);
  document.getElementById('dash-amount').textContent = `₹${calcAmount(totalEgg, totalVeg, totalChicken).toLocaleString('en-IN')}`;

  const tbody = document.getElementById('dashboard-table-body');
  tbody.innerHTML = companies.map(c => {
    const e = getEntry(c.id);
    const total = e.egg + e.veg + e.chicken;
    const amt = calcAmount(e.egg, e.veg, e.chicken);
    const pill = (v, type) => v > 0
      ? `<span class="pill ${type}">${v}</span>`
      : `<span class="pill empty">—</span>`;
    return `<tr>
      <td class="company-name">${c.name}</td>
      <td>${pill(e.egg,'egg')}</td>
      <td>${pill(e.veg,'veg')}</td>
      <td>${pill(e.chicken,'chicken')}</td>
      <td>${total > 0 ? `<span class="pill total-p">${total}</span>` : '<span class="pill empty">—</span>'}</td>
      <td class="amount-cell">${amt > 0 ? `₹${amt.toLocaleString('en-IN')}` : '<span style="color:var(--text-dim)">₹—</span>'}</td>
    </tr>`;
  }).join('');
}

function animateNum(id, target) {
  const el = document.getElementById(id);
  let start = 0;
  const step = Math.ceil(target / 20);
  const t = setInterval(() => {
    start = Math.min(start + step, target);
    el.textContent = start;
    if (start >= target) clearInterval(t);
  }, 30);
}

// ─── DAILY ENTRY ───
function renderDailyEntry() {
  document.getElementById('price-egg-display').textContent = config.prices.egg;
  document.getElementById('price-veg-display').textContent = config.prices.veg;
  document.getElementById('price-chicken-display').textContent = config.prices.chicken;

  const grid = document.getElementById('entry-cards');
  grid.innerHTML = companies.map(c => {
    const e = getEntry(c.id);
    return `
    <div class="entry-card tilt-card" id="ecard-${c.id}">
      <div class="entry-company">${c.name}<span>Client since ${c.since}</span></div>
      <div class="meal-inputs">
        <div class="meal-input-group">
          <div class="meal-input-label egg">🍳 Egg</div>
          <div class="stepper">
            <button class="step-btn" onclick="step(${c.id},'egg',-1)">−</button>
            <input type="number" class="meal-input egg" id="e${c.id}-egg" value="${e.egg}" min="0" oninput="updateCardTotal(${c.id})">
            <button class="step-btn" onclick="step(${c.id},'egg',1)">+</button>
          </div>
        </div>
        <div class="meal-input-group">
          <div class="meal-input-label veg">🥗 Veg</div>
          <div class="stepper">
            <button class="step-btn" onclick="step(${c.id},'veg',-1)">−</button>
            <input type="number" class="meal-input veg" id="e${c.id}-veg" value="${e.veg}" min="0" oninput="updateCardTotal(${c.id})">
            <button class="step-btn" onclick="step(${c.id},'veg',1)">+</button>
          </div>
        </div>
        <div class="meal-input-group">
          <div class="meal-input-label chicken">🍗 Chicken</div>
          <div class="stepper">
            <button class="step-btn" onclick="step(${c.id},'chicken',-1)">−</button>
            <input type="number" class="meal-input chicken" id="e${c.id}-chicken" value="${e.chicken}" min="0" oninput="updateCardTotal(${c.id})">
            <button class="step-btn" onclick="step(${c.id},'chicken',1)">+</button>
          </div>
        </div>
      </div>
      <div class="entry-total">
        <span class="entry-total-label">Today's Amount</span>
        <span class="entry-total-value" id="etotal-${c.id}">₹${calcAmount(e.egg,e.veg,e.chicken).toLocaleString('en-IN')}</span>
      </div>
    </div>`;
  }).join('');

  // Attach tilt
  document.querySelectorAll('.tilt-card').forEach(card => {
    card.addEventListener('mousemove', tilt);
    card.addEventListener('mouseleave', resetTilt);
  });
}

function step(compId, type, dir) {
  const el = document.getElementById(`e${compId}-${type}`);
  el.value = Math.max(0, (+el.value) + dir);
  updateCardTotal(compId);
}

function updateCardTotal(compId) {
  const egg = +document.getElementById(`e${compId}-egg`).value || 0;
  const veg = +document.getElementById(`e${compId}-veg`).value || 0;
  const chicken = +document.getElementById(`e${compId}-chicken`).value || 0;
  document.getElementById(`etotal-${compId}`).textContent = `₹${calcAmount(egg, veg, chicken).toLocaleString('en-IN')}`;
}

async function saveAllEntries() {
  companies.forEach(c => {
    const egg = +document.getElementById(`e${c.id}-egg`).value || 0;
    const veg = +document.getElementById(`e${c.id}-veg`).value || 0;
    const chicken = +document.getElementById(`e${c.id}-chicken`).value || 0;
    setEntry(c.id, egg, veg, chicken);
  });

  // Save Everest Infra (ID 1) record to MySQL if database is connected
  const everest = getEntry(1);
  if (apiEndpoint) {
    await saveToDatabase(everest.egg, everest.veg, everest.chicken, todayKey);
  }

  // Backup all entries to localStorage
  saveLocalBackup();

  document.getElementById('pending-badge').style.display = 'none';
  toast('All entries saved successfully!', '✓');
}

// ─── MONTHLY ───
function renderMonthly() {
  const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  document.getElementById('month-label').textContent = `${months[currentMonth.getMonth()]} ${currentMonth.getFullYear()}`;

  const prefix = `${currentMonth.getFullYear()}-${String(currentMonth.getMonth()+1).padStart(2,'0')}`;
  let totalRev = 0, totalPlates = 0;

  const rows = companies.map(c => {
    let egg=0, veg=0, chicken=0;
    Object.keys(entries).forEach(k => {
      if (k.startsWith(prefix) && k.endsWith(`_${c.id}`)) {
        egg += entries[k].egg; veg += entries[k].veg; chicken += entries[k].chicken;
      }
    });
    const total = egg + veg + chicken;
    const amt = calcAmount(egg, veg, chicken);
    totalRev += amt; totalPlates += total;
    const pill = (v, type) => v > 0 ? `<span class="pill ${type}">${v}</span>` : `<span class="pill empty">—</span>`;
    return `<tr>
      <td class="company-name">${c.name}</td>
      <td>${pill(egg,'egg')}</td><td>${pill(veg,'veg')}</td><td>${pill(chicken,'chicken')}</td>
      <td>${total > 0 ? `<span class="pill total-p">${total}</span>` : '<span class="pill empty">—</span>'}</td>
      <td class="amount-cell">${amt > 0 ? `₹${amt.toLocaleString('en-IN')}` : '<span style="color:var(--text-dim)">₹—</span>'}</td>
    </tr>`;
  }).join('');

  document.getElementById('monthly-revenue').textContent = `₹${totalRev.toLocaleString('en-IN')}`;
  document.getElementById('monthly-plates').textContent = totalPlates;
  const daysInMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth()+1, 0).getDate();
  document.getElementById('monthly-avg').textContent = `₹${Math.round(totalRev/daysInMonth).toLocaleString('en-IN')}`;
  document.getElementById('monthly-table-body').innerHTML = rows;
}

function prevMonth() {
  currentMonth.setMonth(currentMonth.getMonth() - 1);
  renderMonthly();
}
function nextMonth() {
  currentMonth.setMonth(currentMonth.getMonth() + 1);
  renderMonthly();
}

// ─── COMPANIES ───
function renderCompanies() {
  document.getElementById('companies-grid').innerHTML = companies.map(c => {
    const e = getEntry(c.id);
    const total = e.egg + e.veg + e.chicken;
    const amt = calcAmount(e.egg, e.veg, e.chicken);
    return `
    <div class="company-card">
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <div class="company-card-name">${c.name}</div>
          <div class="company-card-meta">Client since ${c.since}</div>
        </div>
        <div style="font-size:22px;opacity:.5">🏢</div>
      </div>
      <div class="company-stats">
        <div class="company-stat">
          <div class="company-stat-val" style="color:var(--egg)">${e.egg}</div>
          <div class="company-stat-lbl">Egg</div>
        </div>
        <div class="company-stat">
          <div class="company-stat-val" style="color:var(--veg)">${e.veg}</div>
          <div class="company-stat-lbl">Veg</div>
        </div>
        <div class="company-stat">
          <div class="company-stat-val" style="color:var(--chicken)">${e.chicken}</div>
          <div class="company-stat-lbl">Chicken</div>
        </div>
        <div class="company-stat">
          <div class="company-stat-val" style="color:var(--gold)">₹${amt.toLocaleString('en-IN')}</div>
          <div class="company-stat-lbl">Today</div>
        </div>
      </div>
    </div>`;
  }).join('');
}

// ─── SETUP ───
function renderSetup() {
  document.getElementById('cfg-egg').value = config.prices.egg;
  document.getElementById('cfg-veg').value = config.prices.veg;
  document.getElementById('cfg-chicken').value = config.prices.chicken;
  document.getElementById('cfg-default-meal').value = config.defaultMeal;
  document.getElementById('cfg-name').value = config.messName;
  document.getElementById('cfg-loc').value = config.location;
}

function saveSetup() {
  config.prices.egg = +document.getElementById('cfg-egg').value;
  config.prices.veg = +document.getElementById('cfg-veg').value;
  config.prices.chicken = +document.getElementById('cfg-chicken').value;
  config.defaultMeal = document.getElementById('cfg-default-meal').value;
  config.messName = document.getElementById('cfg-name').value;
  config.location = document.getElementById('cfg-loc').value;
  toast('Settings saved!', '⚙');
}

function addCompanyFromSetup() {
  const name = document.getElementById('new-company-name').value.trim();
  if (!name) { toast('Please enter a company name', '⚠'); return; }
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  companies.push({
    id: Date.now(),
    name,
    since: `${months[today.getMonth()]} ${today.getFullYear()}`
  });
  document.getElementById('new-company-name').value = '';
  toast(`"${name}" added!`, '🏢');
}

function showAddCompany() {
  showPage('setup', document.querySelectorAll('.nav-item')[4]);
  setTimeout(() => document.getElementById('new-company-name').focus(), 400);
}

// ─── 3D TILT ───
function tilt(e) {
  const card = this;
  const rect = card.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;
  const cx = rect.width / 2, cy = rect.height / 2;
  const rx = (y - cy) / cy * -6;
  const ry = (x - cx) / cx * 6;
  card.style.transform = `perspective(1000px) rotateX(${rx}deg) rotateY(${ry}deg) translateY(-4px)`;
}

function resetTilt() {
  this.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateY(0)';
}

// ─── INIT ───
(function init() {
  document.querySelectorAll('.tilt-card').forEach(card => {
    card.addEventListener('mousemove', tilt);
    card.addEventListener('mouseleave', resetTilt);
  });
  // Auto-detect MySQL backend on launch and sync historical data
  detectBackend();
})();
