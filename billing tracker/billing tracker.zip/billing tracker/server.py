import http.server
import socketserver
import json
import urllib.parse
import sys
import subprocess
import os

PORT = 8000

# Try to import pymysql for MySQL connectivity. If missing, attempt automatic pip installation.
try:
    import pymysql
except ImportError:
    print("MySQL client library 'pymysql' is missing. Attempting to install automatically...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pymysql"])
        import pymysql
    except Exception as e:
        print(f"Automatic installation of 'pymysql' failed: {e}")
        print("Please install 'pymysql' manually by running: pip install pymysql")
        sys.exit(1)

class MessTrackerHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200, "OK")
        self.end_headers()

    def do_GET(self):
        parsed_path = urllib.parse.urlparse(self.path)
        if parsed_path.path == '/api/meals' or parsed_path.path == '/api.php':
            self.handle_get_meals()
        else:
            # Fall back to serving static files (index.html, style.css, script.js)
            super().do_GET()

    def do_POST(self):
        parsed_path = urllib.parse.urlparse(self.path)
        if parsed_path.path == '/api/meals' or parsed_path.path == '/api.php':
            self.handle_post_meals()
        else:
            self.send_error(404, "Endpoint Not Found")

    def get_db_connection(self):
        # Default XAMPP MySQL configuration: localhost, root, no password
        return pymysql.connect(
            host='127.0.0.1',
            user='root',
            password='',
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor
        )

    def handle_get_meals(self):
        try:
            conn = self.get_db_connection()
            with conn.cursor() as cursor:
                # Create Database if it does not exist
                cursor.execute("CREATE DATABASE IF NOT EXISTS `messdb` COLLATE utf8mb4_general_ci")
                conn.select_db('messdb')
                
                table_name = "everest infra ventures india pvt. ltd."
                cursor.execute(f"""
                    CREATE TABLE IF NOT EXISTS `{table_name}` (
                        `EGG` int(11) NOT NULL,
                        `VEG` int(11) NOT NULL,
                        `CHICKEN` int(11) NOT NULL
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
                """)
                
                # Check for entry_date column
                cursor.execute(f"SHOW COLUMNS FROM `{table_name}` LIKE 'entry_date'")
                has_date = cursor.fetchone()
                
                if not has_date:
                    cursor.execute(f"ALTER TABLE `{table_name}` ADD COLUMN `entry_date` DATE NOT NULL UNIQUE FIRST")
                    conn.commit()

                # Fetch all rows sorted by date descending
                cursor.execute(f"SELECT * FROM `{table_name}` ORDER BY `entry_date` DESC")
                rows = cursor.fetchall()
                
                # Format python date objects to string for JSON output
                for r in rows:
                    if 'entry_date' in r:
                        r['entry_date'] = str(r['entry_date'])

            conn.close()
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "success", "data": rows}).encode('utf-8'))
            
        except Exception as e:
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "error", "message": f"Database error: {str(e)}"}).encode('utf-8'))

    def handle_post_meals(self):
        try:
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data.decode('utf-8'))
            
            egg = int(data.get('egg', 0))
            veg = int(data.get('veg', 0))
            chicken = int(data.get('chicken', 0))
            date = data.get('date', '')
            
            if not date:
                from datetime import datetime
                date = datetime.now().strftime('%Y-%m-%d')
            
            conn = self.get_db_connection()
            with conn.cursor() as cursor:
                cursor.execute("CREATE DATABASE IF NOT EXISTS `messdb` COLLATE utf8mb4_general_ci")
                conn.select_db('messdb')
                
                table_name = "everest infra ventures india pvt. ltd."
                
                # Check for entry_date column
                cursor.execute(f"SHOW COLUMNS FROM `{table_name}` LIKE 'entry_date'")
                has_date = cursor.fetchone()
                
                if not has_date:
                    cursor.execute(f"ALTER TABLE `{table_name}` ADD COLUMN `entry_date` DATE NOT NULL UNIQUE FIRST")
                    conn.commit()
                
                # Insert or update if entry_date already exists
                sql = f"""
                    INSERT INTO `{table_name}` (`entry_date`, `EGG`, `VEG`, `CHICKEN`) 
                    VALUES (%s, %s, %s, %s) 
                    ON DUPLICATE KEY UPDATE `EGG` = %s, `VEG` = %s, `CHICKEN` = %s
                """
                cursor.execute(sql, (date, egg, veg, chicken, egg, veg, chicken))
                conn.commit()

            conn.close()
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "success", "message": "Successfully synchronized with MySQL database!"}).encode('utf-8'))
            
        except Exception as e:
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "error", "message": f"Database error: {str(e)}"}).encode('utf-8'))

if __name__ == '__main__':
    print(f"\n=======================================================")
    print(f"SRI KARTHIKEYA DELUXE MESS - BILLING TRACKER SERVER")
    print(f"=======================================================")
    print(f"Starting developer server at: http://localhost:{PORT}")
    print(f"Serving static files from: {os.getcwd()}")
    print(f"Sync target: MySQL Database 'messdb' on port 3306")
    print(f"To stop server, press CTRL+C")
    print(f"=======================================================\n")
    
    # Allow port reuse to avoid 'Address already in use' errors
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", PORT), MessTrackerHandler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down developer server...")
            sys.exit(0)
