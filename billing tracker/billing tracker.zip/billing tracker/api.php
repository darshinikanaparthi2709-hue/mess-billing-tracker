<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "messdb";
$table = "everest infra ventures india pvt. ltd.";

// Connect to MySQL Server
$conn = new mysqli($servername, $username, $password);

// Verify connection
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Create database if it does not exist
$conn->query("CREATE DATABASE IF NOT EXISTS `$dbname` COLLATE utf8mb4_general_ci");
$conn->select_db($dbname);

// Create table if it does not exist
$createTableSQL = "CREATE TABLE IF NOT EXISTS `$table` (
    `EGG` int(11) NOT NULL,
    `VEG` int(11) NOT NULL,
    `CHICKEN` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
$conn->query($createTableSQL);

// Add primary/unique DATE column if not already present to track entries per-date
$checkDateColumn = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'entry_date'");
$hasDateColumn = ($checkDateColumn->num_rows > 0);

if (!$hasDateColumn) {
    $conn->query("ALTER TABLE `$table` ADD COLUMN `entry_date` DATE NOT NULL UNIQUE FIRST");
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' || $action === 'save') {
    // Read JSON payload
    $data = json_decode(file_get_contents("php://input"), true);
    
    $egg = isset($data['egg']) ? intval($data['egg']) : 0;
    $veg = isset($data['veg']) ? intval($data['veg']) : 0;
    $chicken = isset($data['chicken']) ? intval($data['chicken']) : 0;
    $date = isset($data['date']) ? $data['date'] : date('Y-m-d');
    
    // Insert or update based on duplicate key 'entry_date'
    $stmt = $conn->prepare("INSERT INTO `$table` (entry_date, EGG, VEG, CHICKEN) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE EGG = ?, VEG = ?, CHICKEN = ?");
    $stmt->bind_param("siiiiii", $date, $egg, $veg, $chicken, $egg, $veg, $chicken);
    
    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Successfully saved record for $date to MySQL database!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to save record: " . $stmt->error]);
    }
    $stmt->close();

} else {
    // Default: GET / load entries
    $result = $conn->query("SELECT * FROM `$table` ORDER BY entry_date DESC");
    
    $dataRows = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $dataRows[] = $row;
        }
    }
    
    echo json_encode([
        "status" => "success",
        "data" => $dataRows
    ]);
}

$conn->close();
?>
